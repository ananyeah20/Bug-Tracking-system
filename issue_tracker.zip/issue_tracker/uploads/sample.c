#include <stdio.h>

int main()
{
	printf("Hi");
}
