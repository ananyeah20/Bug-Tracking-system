<?php
echo "Hello World";
echo "Hi";
?>